import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';

const CareerPredictor = () => {
  const [formData, setFormData] = useState({
    // Initialize with all required fields
    osPercentage: '',
    algorithmsPercentage: '',
    // ... all other fields
  });
  const [prediction, setPrediction] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // Prepare input data in correct order
      const inputData = [
        parseFloat(formData.osPercentage),
        parseFloat(formData.algorithmsPercentage),
        // ... all other fields in correct order
      ];
      
      // Call API endpoint that uses the CareerGuidanceModel
      const response = await fetch('/api/predict-career', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ input_data: inputData }),
      });
      
      const result = await response.json();
      setPrediction(result.prediction);
    } catch (error) {
      console.error('Prediction error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6">Career Path Predictor</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="osPercentage">Operating Systems Percentage</Label>
          <Input
            id="osPercentage"
            name="osPercentage"
            type="number"
            value={formData.osPercentage}
            onChange={handleChange}
            required
          />
        </div>
        
        <div>
          <Label htmlFor="algorithmsPercentage">Algorithms Percentage</Label>
          <Input
            id="algorithmsPercentage"
            name="algorithmsPercentage"
            type="number"
            value={formData.algorithmsPercentage}
            onChange={handleChange}
            required
          />
        </div>
        
        {/* Add all other input fields */}
        
        <Button type="submit" disabled={loading}>
          {loading ? 'Predicting...' : 'Predict Career Path'}
        </Button>
      </form>
      
      {prediction && (
        <div className="mt-6 p-4 bg-gray-50 rounded-md">
          <h3 className="text-lg font-semibold">Recommended Career Path:</h3>
          <p className="text-xl mt-2">{prediction}</p>
        </div>
      )}
    </div>
  );
};

export default CareerPredictor;