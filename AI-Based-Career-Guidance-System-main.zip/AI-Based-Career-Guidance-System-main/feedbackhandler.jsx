const sendFeedback = async (isHelpful) => {
    await fetch('/api/log-feedback', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        sessionId: /* unique session ID */
        isHelpful,
        suggestedImprovement: isHelpful ? null : prompt('How could we improve?')
      })
    });
  };