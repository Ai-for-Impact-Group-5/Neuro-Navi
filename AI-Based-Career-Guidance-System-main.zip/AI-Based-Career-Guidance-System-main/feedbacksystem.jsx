{prediction && (
  <div className="mt-6 space-y-4">
    <div className="p-4 bg-gray-50 rounded-md">
      <h3 className="text-lg font-semibold">Recommended Career Path:</h3>
      <p className="text-xl mt-2">{prediction}</p>
    </div>
    
    <div className="p-4 border rounded-md">
      <h4 className="font-medium">Was this prediction helpful?</h4>
      <div className="flex space-x-4 mt-2">
        <Button variant="outline" onClick={() => sendFeedback(true)}>
          👍 Yes
        </Button>
        <Button variant="outline" onClick={() => sendFeedback(false)}>
          👎 No
        </Button>
      </div>
    </div>
  </div>
)}
