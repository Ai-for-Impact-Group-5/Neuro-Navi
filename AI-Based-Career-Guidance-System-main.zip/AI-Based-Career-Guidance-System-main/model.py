import numpy as np
import pandas as pd
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder, Normalizer
from sklearn.model_selection import train_test_split

class CareerGuidanceModel:
    def __init__(self):
        self.model = SVC()
        self.label_encoder = LabelEncoder()
        self.normalizer = Normalizer()
        self.features = [
            'Acedamic percentage in Operating Systems', 'percentage in Algorithms',
            'Percentage in Programming Concepts', 'Percentage in Software Engineering', 
            'Percentage in Computer Networks', 'Percentage in Electronics Subjects',
            'Percentage in Computer Architecture', 'Percentage in Mathematics',
            'Percentage in Communication skills', 'Hours working per day',
            'Logical quotient rating', 'hackathons', 'coding skills rating',
            'public speaking points', 'can work long time before system?',
            'self-learning capability?', 'Extra-courses did', 'certifications',
            'workshops', 'talenttests taken?', 'olympiads',
            'reading and writing skills', 'memory capability score',
            'Interested subjects', 'interested career area ', 'Job/Higher Studies?',
            'Type of company want to settle in?', 'Taken inputs from seniors or elders', 
            'interested in games', 'Interested Type of Books', 'Salary Range Expected',
            'In a Realtionship?', 'Gentle or Tuff behaviour?',
            'Management or Technical', 'Salary/work', 'hard/smart worker',
            'worked in teams ever?', 'Introvert'
        ]
        self.job_roles = {
            0: 'Applications Developer',
            1: 'Business Intelligence Analyst',
            2: 'Business Systems Analyst',
            3: 'CRM Business Analyst',
            4: 'CRM Technical Developer',
            5: 'Data Architect',
            6: 'Database Administrator',
            7: 'Database Developer',
            8: 'Database Manager',
            9: 'Design & UX',
            10: 'E-Commerce Analyst',
            11: 'Information Security Analyst',
            12: 'Information Technology Auditor',
            13: 'Information Technology Manager',
            14: 'Mobile Applications Developer',
            15: 'Network Engineer',
            16: 'Network Security Administrator',
            17: 'Network Security Engineer',
            18: 'Portal Administrator',
            19: 'Programmer Analyst',
            20: 'Project Manager',
            21: 'Quality Assurance Associate',
            22: 'Software Developer',
            23: 'Software Engineer',
            24: 'Software Quality Assurance (QA) / Testing',
            25: 'Software Systems Engineer',
            26: 'Solutions Architect',
            27: 'Systems Analyst',
            28: 'Systems Security Administrator',
            29: 'Technical Engineer',
            30: 'Technical Services/Help Desk/Tech Support',
            31: 'Technical Support',
            32: 'UX Designer',
            33: 'Web Developer'
        }
        
    def load_data(self, url='/Career-Guidance-ML-Project/master/career_pred.csv'):
        df = pd.read_csv(url)
        return df
        
    def preprocess_data(self, df):
        # Separate features and label
        data = df.iloc[:,:-1].values
        label = df.iloc[:,-1]
        
        # Label encoding for categorical features
        labelencoder = LabelEncoder()
        for i in range(14,38):
            data[:,i] = labelencoder.fit_transform(data[:,i])
            
        # Normalize numerical features
        data1 = data[:,:14]
        normalized_data = self.normalizer.fit_transform(data1)
        
        data2 = data[:,14:]
        processed_data = np.append(normalized_data, data2, axis=1)
        
        # Encode labels
        label = label.values
        label_encoded = self.label_encoder.fit_transform(label)
        
        return processed_data, label_encoded
        
    def train_model(self):
        df = self.load_data()
        X, y = self.preprocess_data(df)
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=10)
        self.model.fit(X_train, y_train)
        return self.model.score(X_test, y_test)
        
    def predict_career(self, input_data):
        # Preprocess input data same way as training data
        numerical_data = input_data[:14]
        categorical_data = input_data[14:]
        
        # Normalize numerical features
        numerical_normalized = self.normalizer.transform([numerical_data])[0]
        
        # Combine with categorical
        processed_input = np.append(numerical_normalized, categorical_data)
        
        # Make prediction
        prediction = self.model.predict([processed_input])[0]
        return self.job_roles[prediction]