import { CareerGuidanceModel } from '../../lib/careerModel';

const model = new CareerGuidanceModel();

// Train model on first load (in production you'd want to pre-train and save)
let isModelTrained = false;

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    if (!isModelTrained) {
      await model.train_model();
      isModelTrained = true;
    }

    const { input_data } = req.body;
    const prediction = model.predict_career(input_data);
    
    res.status(200).json({ prediction });
  } catch (error) {
    console.error('Prediction error:', error);
    res.status(500).json({ message: 'Error making prediction' });
  }
}